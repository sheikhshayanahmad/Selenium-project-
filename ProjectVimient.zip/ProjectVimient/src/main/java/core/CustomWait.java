package core;


import org.openqa.selenium.JavascriptExecutor;
        import org.openqa.selenium.WebDriver;
        import org.openqa.selenium.support.ui.ExpectedCondition;
        import org.openqa.selenium.support.ui.WebDriverWait;

public class CustomWait {

    private final WebDriver driver;
    private final WebDriverWait wait;

    public CustomWait(WebDriver driver, WebDriverWait wait) {
        this.driver = driver;
        this.wait = wait;
    }

    // Custom wait for JavaScript-based page loading
    public void waitForPageToLoad() {
        ExpectedCondition<Boolean> pageLoadCondition = driver -> {
            String script = "return document.readyState";
            Object result = ((JavascriptExecutor) driver).executeScript(script);
            return result.equals("complete");
        };

        wait.until(pageLoadCondition);
    }
}
