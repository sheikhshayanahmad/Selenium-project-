//package locators;
//
//import org.openqa.selenium.WebDriver;
//
//public class DashboardLocators {
//
//    private WebDriver driver;
//
//    public DashboardLocators(WebDriver driver) {
//        this.driver = driver;
//    }
//
//
//    private String Senior_Tanu_CSS = "tr.MuiTableRow-root[data-testid=\"navigateToDashboard\"]";
//}
