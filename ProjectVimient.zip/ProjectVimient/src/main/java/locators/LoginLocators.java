package locators;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import java.time.Duration;
import core.CustomWait;
import org.openqa.selenium.Alert;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.JavascriptExecutor;

public class LoginLocators {
    private WebDriver driver;
    private WebDriverWait wait;
    private CustomWait customWait;

//    private String USERNAME_EMAIL_ID = "email";
//    private String USERNAME_PASSWORD_ID ="password";
//    private String USERNAME_BUTTON_CSS ="button[type='submit']";
//
//    private String Senior_Tanu_CSS = "tbody.MuiTableBody-root>tr:nth-of-type(1)";
//    private String Assessment_css = "div[class='MuiBox-root css-1lzo07v-container']>div:nth-child(4)";
    private String WELLBEING_SURVEY_XPATH ="//button[normalize-space()='Wellbeing Survey']";
//    private String WELLBEING_SURVEY_CSS =".MuiButtonBase-root.MuiButton-root.MuiButton-contained.MuiButton-containedPrimary.MuiButton-sizeMedium.MuiButton-containedSizeMedium.MuiButton-root.MuiButton-contained.MuiButton-containedPrimary.MuiButton-sizeMedium.MuiButton-containedSizeMedium.css-138llji";

    private String WELLBEING_SURVEY_BORED_XPATH ="//span[text()='Bored']";

    private String WELLBEING_SURVEY_BORED_TEXTAREA_CSS = "textarea[name='engagement']";

    private String WELLBEIGN_SURVEY_BORED_LEVEL_CSS = "input[value='low'][name='engagement']";

    //    loctors for Wellbeing Dashboard happy or sad

//    private String WELLBEING_SURVEY_HAPPY_XPATH = "//input[contains(@value, 'Happy/Cheerful')][@name='happiness']";
    private String WELLBEING_SURVEY_HAPPY_XPATH = "(//span[@class='MuiTypography-root MuiTypography-body1 MuiFormControlLabel-label css-17pxxqj'])[6]";

    private String WELLBEING_SURVEY_HAPPY_TEXTAREA_CSS = "textarea[name='happiness']";


//    Reset button
    private String WELLBEING_SURVEY_RESST_BUTTON_XPATH = "//button[normalize-space()='Reset']";
    private String WELLBEING_SURVEY_RESET_BUTTON_OK_XPATH = "//button[normalize-space()='OK']";
    private String WELLBEING_SURVEY_RESET_BUTTON_OK_CROSS_XPATH = "div[class='MuiBox-root css-39sfk3-successContainer']";

//     loctors for Wellbeing Dashboard purpose or no purpose
    private String WELLBEING_SURVEY_NO_PURPOSE_XAPTH = "(//input[@value='Aimless/Insignificant'])[1]";
    private String WELLBEING_SURVEY_NO_PURPOSE_TEXTAREA_CSS = "textarea[name='purpose']";
    private String WELLBEING_SURVEY_NO_PURPOSE_LEVEL_CSS = "input[name='purpose'][value='high']";

    //    loctors for Wellbeing Dashboard social or sad

    private String WELLBEING_SURVEY_SOCIAL_LONEYLY_CSS = "input[value='Socially Active/Fulfilled']";

    //    loctors for Wellbeing Dashboard relaxed or stressed
    private String WELLBEING_SURVEY_STRESSED_CSS ="input[value='Stressed/Anxiety']";
    private String WELLBEING_SURVEY_STRESSED_LEVEL_CSS = "input[value='high'][name='relax']";

    //    loctors for Wellbeing Dashboard PAIN FREE OR PAIN
    private String WELLBEING_SURVEY_PAIN_FREE_CSS = "input[value='Feeling Good/Content']";

    //    loctors for Wellbeing Dashboard rested or tired
    private String WELLBEING_SURVEY_PATH_RESTED_CSS ="input[value='Rested/Energized']";


    private String WELLBEING_SURVEY_SUBMIT_BUTTON_XAPTH ="//button[normalize-space()='Submit']";





    public LoginLocators(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(15));
        this.customWait = new CustomWait(driver, wait);


    }

//    public WebElement enterUsername() {
//
////        return wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(USERNAME_EMAIL_ID)));
//
//        return driver.findElement(By.id(USERNAME_EMAIL_ID));
//    }
//    public WebElement enterPassword(){return driver.findElement(By.id(USERNAME_PASSWORD_ID));}
//    public WebElement clickButton(){return driver.findElement(By.cssSelector(USERNAME_BUTTON_CSS));}
//    public WebElement clickSenior() {
//        customWait.waitForPageToLoad();
//
//            System.out.println("Waiting for the element to be present...");
//        return wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector(Senior_Tanu_CSS)));
//
//
//
////        return driver.findElement(By.cssSelector(Senior_Tanu_CSS));
//    }
//
//    public WebElement clickAssessment() {
//        return wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(Assessment_css)));
//
////        return driver.findElement(By.cssSelector(Assessment_css));
//    }
    public WebElement clickWellBeingSurvey() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(WELLBEING_SURVEY_XPATH)));

//        return driver.findElement(By.cssSelector(WELLBEING_SURVEY_CSS));
    }

    public WebElement clickWellBeingBored() {
        return wait.until(ExpectedConditions.elementToBeClickable(By.xpath(WELLBEING_SURVEY_BORED_XPATH)));

//        return wait.until(ExpectedConditions.elementToBeClickable(By.xpath(WELLBEING_SURVEY_BORED_XPATH)));

//        return driver.findElement(By.cssSelector(WELLBEING_SURVEY_BORED_XPATH));

    }

    public WebElement clickWellBeingBoredLevel() {

//        return wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(WELLBEIGN_SURVEY_BORED_LEVEL_CSS)));

        return driver.findElement(By.cssSelector(WELLBEIGN_SURVEY_BORED_LEVEL_CSS));
    }
    public WebElement clickWellBeingBoredTextArea() {

        return wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(WELLBEING_SURVEY_BORED_TEXTAREA_CSS)));

//        return driver.findElement(By.cssSelector(WELLBEING_SURVEY_BORED_TEXTAREA_CSS));
    }


//    loctors for Wellbeing Dashboard happy or sad


//    public WebElement clickWellBeingHappy() {
//        try {
//            WebElement happinessInput = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(WELLBEING_SURVEY_HAPPY_CSS)));
//
//            // Use JavascriptExecutor to click on the element
//            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", happinessInput);
//
//            // Return the WebElement after clicking
//            return happinessInput;
//        } catch (TimeoutException e) {
//            System.out.println("TimeoutException: " + e.getMessage());
//            throw e; // Re-throw the exception to indicate failure
//        }
//    }


    public WebElement clickWellBeingHappy() {
        return wait.until(ExpectedConditions.elementToBeClickable(By.xpath(WELLBEING_SURVEY_HAPPY_XPATH)));

//        return driver.findElement(By.cssSelector(WELLBEING_SURVEY_HAPPY_CSS));
    }
    public WebElement clickWellBeingHappyTextArea() {
        return wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(WELLBEING_SURVEY_HAPPY_TEXTAREA_CSS)));

//        return driver.findElement(By.cssSelector(WELLBEING_SURVEY_HAPPY_CSS));
    }


    public WebElement clickWellBeingNoPurpose() {
//        return wait.until(ExpectedConditions.elementToBeClickable(By.xpath(WELLBEING_SURVEY_NO_PURPOSE_CSS)));

        return driver.findElement(By.xpath(WELLBEING_SURVEY_NO_PURPOSE_XAPTH));
    }
    public WebElement clickWellBeingNoPurposeTextArea() {
//        return wait.until(ExpectedConditions.elementToBeClickable(By.xpath(WELLBEING_SURVEY_NO_PURPOSE_TEXTAREA_CSS)));

        return driver.findElement(By.cssSelector(WELLBEING_SURVEY_NO_PURPOSE_TEXTAREA_CSS));
    }
    public WebElement clickWellBeingNoPurposeLevel() {
//        return wait.until(ExpectedConditions.elementToBeClickable(By.xpath(WELLBEING_SURVEY_NO_PURPOSE_TEXTAREA_CSS)));

        return driver.findElement(By.cssSelector(WELLBEING_SURVEY_NO_PURPOSE_LEVEL_CSS));
    }
    public WebElement clickWellBeingSocial() {
//        return wait.until(ExpectedConditions.elementToBeClickable(By.xpath(WELLBEING_SURVEY_SOCIAL_LONEYLY)));

        return driver.findElement(By.cssSelector(WELLBEING_SURVEY_SOCIAL_LONEYLY_CSS));
    }
    public WebElement clickWellBeingStressed() {
//        return wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(WELLBEING_SURVEY_STRESSED_CSS)));

        return driver.findElement(By.cssSelector(WELLBEING_SURVEY_STRESSED_CSS));
    }
    public WebElement clickWellBeingStressedLevel() {
//        return wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(WELLBEING_SURVEY_STRESSED_CSS)));

        return driver.findElement(By.cssSelector(WELLBEING_SURVEY_STRESSED_LEVEL_CSS));
    }
    public WebElement clickWellBeingPainFree() {
//        return wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(WELLBEING_SURVEY_PAIN_FREE_CSS)));

        return driver.findElement(By.cssSelector(WELLBEING_SURVEY_PAIN_FREE_CSS));
    }

    public WebElement clickWellBeingRESTED() {
//        return wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(WELLBEING_SURVEY_PATH_RESTED_CSS)));

        return driver.findElement(By.cssSelector(WELLBEING_SURVEY_PATH_RESTED_CSS));
    }

    public WebElement clickWellBeingSubmitButton() {
        return wait.until(ExpectedConditions.elementToBeClickable(By.xpath(WELLBEING_SURVEY_SUBMIT_BUTTON_XAPTH)));

//        return driver.findElement(By.cssSelector(WELLBEING_SURVEY_SUBMIT_BUTTON));
    }






    public WebElement clickWellBeingResetButton() {
        return wait.until(ExpectedConditions.elementToBeClickable(By.xpath(WELLBEING_SURVEY_RESST_BUTTON_XPATH)));

//        return driver.findElement(By.xpath(WELLBEING_SURVEY_RESST_BUTTON));
    }
    public WebElement clickWellBeingResetButtonOK() {
        return wait.until(ExpectedConditions.elementToBeClickable(By.xpath(WELLBEING_SURVEY_RESET_BUTTON_OK_XPATH)));

//        return driver.findElement(By.xpath(WELLBEING_SURVEY_RESET_BUTTON_OK_XPATH));
    }
    public WebElement clickWellBeingResetButtonOKCross() {
        return wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(WELLBEING_SURVEY_RESET_BUTTON_OK_CROSS_XPATH)));

//        return driver.findElement(By.xpath(WELLBEING_SURVEY_RESET_BUTTON_OK_CROSS_XPATH));
    }






//    public void handleAlertAfterReset() {
//        // Switch to the alert
//        Alert alert = driver.switchTo().alert();
//
//        // Optionally get the text of the alert
//        String alertText = alert.getText();
//        System.out.println("Alert Text: " + alertText);
//
//        // Perform the action on the alert (e.g., accept or dismiss)
//        alert.accept();  // To click OK
//        // OR
//        // alert.dismiss(); // To click Cancel
//
//        // Switch back to the main window (if needed)
//        driver.switchTo().defaultContent();
//    }




    public void closeBrowser() {
        driver.quit();
    }


}
