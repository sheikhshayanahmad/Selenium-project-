package locators;

import core.CustomWait;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class MedicationListLocators {

    private WebDriverWait wait;
    private WebDriver driver;
//    private String USERNAME_EMAIL_ID = "email";
//    private String USERNAME_PASSWORD_ID ="password";
//    private String USERNAME_BUTTON_CSS ="button[type='submit']";
//
//    private String Senior_Tanu_CSS = "tbody.MuiTableBody-root>tr:nth-of-type(1)";
//    private String Assessment_css = "div[class='MuiBox-root css-1lzo07v-container']>div:nth-child(4)";
    private String MEDICATION_LIST_BUTTON_XPATH ="//h2[text()='Medication List']";
    private  String ADD_MEDICATION_BUTTON_XPATH = "//button[text()='Add Medication']";
    private String SEARCH_MEDICATION_CSS ="form[data-testid='SearchBar'] input";
    private String SEARCH_OPTION_SELECT_XPATH = "//span[text()='S-adenosylmethionine (Oral Pill) 200 mg Tab']";
    private String SEARCH_DOSE_FORM_ID ="mui-component-select-doseForm";
    private  String SEARCH_DOSE_FORM_NAME_XPATH = "//li[text()='Liquid, Oral']";
    private String SEARCH_TIME_DURATION_XPATH = "//span[text()='Morning']";

    private String SEARCH_MEDICATION_DATE_PRESCRIBED_CSS = "button[aria-label='Choose date']";
    private  String SEARCH_MEDICATION_TEXTAREA_CSS ="textarea[name='note']";
    private String SEARCH_MEDICATION_DOSE_FREQUENCY_TIME_ID ="mui-component-select-doseFrequencyTime";
    private String SEARCH_MEDICATION_DOSE_FREQUENCY_TIME_NO_XPATH ="//li[text()='3']";

    private String SEARCH_MEDICATION_DOSE_FREQUENCY_UNIT_ID ="mui-component-select-doseFrequencyUnit";
    private String SEARCH_MEDICATION_DOSE_FREQUENCY_UNIT_DURATION_XPATH ="//li[text()='Week']";

    private String SEARCH_MEDICATION_DATE_DISCONTINUED_CSS = "input[name='dateDiscontinued']";
    private String MEDICATION_LIST_SUBMIT_BUTTON_XPATH = "//button[text()='Submit']";






    public MedicationListLocators(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(15));
//        this.customWait = new CustomWait(driver, wait);


    }

//    public WebElement enterUsername() {
//
////        return wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(USERNAME_EMAIL_ID)));
//
//        return driver.findElement(By.id(USERNAME_EMAIL_ID));
//    }
//    public WebElement enterPassword(){return driver.findElement(By.id(USERNAME_PASSWORD_ID));}
//    public WebElement clickButton(){return driver.findElement(By.cssSelector(USERNAME_BUTTON_CSS));}
//    public WebElement clickSenior() {
//
//
//
//        System.out.println("Waiting for the element to be present...");
//        return wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector(Senior_Tanu_CSS)));
//
//
//
////        return driver.findElement(By.cssSelector(Senior_Tanu_CSS));
//    }
//
//    public WebElement clickAssessment() {
//        return wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(Assessment_css)));
//
////        return driver.findElement(By.cssSelector(Assessment_css));
//    }
    public WebElement clickMedicationList() {
        return wait.until(ExpectedConditions.elementToBeClickable(By.xpath(MEDICATION_LIST_BUTTON_XPATH)));

//        return driver.findElement(By.cssSelector(Assessment_css));
    }
    public WebElement clickAddMedication() {
        return wait.until(ExpectedConditions.elementToBeClickable(By.xpath(ADD_MEDICATION_BUTTON_XPATH)));

//        return driver.findElement(By.cssSelector(Assessment_css));
    }
    public WebElement clickSearchMedication() {
        return wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(SEARCH_MEDICATION_CSS)));

//        return driver.findElement(By.cssSelector(Assessment_css));
    }
    public WebElement clickSearchMedicationOption() {
        return wait.until(ExpectedConditions.elementToBeClickable(By.xpath(SEARCH_OPTION_SELECT_XPATH)));

//        return driver.findElement(By.cssSelector(Assessment_css));
    }
    public WebElement clickSearchMedicationDoseForm() {
        return wait.until(ExpectedConditions.elementToBeClickable(By.id(SEARCH_DOSE_FORM_ID)));

//        return driver.findElement(By.cssSelector(Assessment_css));
    }
    public WebElement clickSearchMedicationDoseFormName() {
        return wait.until(ExpectedConditions.elementToBeClickable(By.xpath(SEARCH_DOSE_FORM_NAME_XPATH)));

//        return driver.findElement(By.cssSelector(Assessment_css));
    }

    public WebElement clickSearchMedicationDoseDuration() {
        return wait.until(ExpectedConditions.elementToBeClickable(By.xpath(SEARCH_TIME_DURATION_XPATH)));

//        return driver.findElement(By.cssSelector(Assessment_css));
    }
    public WebElement clickSearchMedicationDatePrescribed() {
        return wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(SEARCH_MEDICATION_DATE_PRESCRIBED_CSS)));

//        return driver.findElement(By.cssSelector(Assessment_css));
    }
    public WebElement clickSearchMedicationTextArea() {
        return wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(SEARCH_MEDICATION_TEXTAREA_CSS)));

//        return driver.findElement(By.cssSelector(Assessment_css));
    }

    public WebElement clickSearchMedicationDoseFrquencyTIME() {
        return wait.until(ExpectedConditions.elementToBeClickable(By.id(SEARCH_MEDICATION_DOSE_FREQUENCY_TIME_ID)));

//        return driver.findElement(By.cssSelector(Assessment_css));
    }
    public WebElement clickSearchMedicationDoseFrquencyTIMENo() {
        return wait.until(ExpectedConditions.elementToBeClickable(By.xpath(SEARCH_MEDICATION_DOSE_FREQUENCY_TIME_NO_XPATH)));

//        return driver.findElement(By.cssSelector(Assessment_css));
    }


    public WebElement clickSearchMedicationDoseFrquencyUNIT() {
        return wait.until(ExpectedConditions.elementToBeClickable(By.id(SEARCH_MEDICATION_DOSE_FREQUENCY_UNIT_ID)));

//        return driver.findElement(By.cssSelector(Assessment_css));
    }
    public WebElement clickSearchMedicationDoseFrquencyUNITDuration() {
        return wait.until(ExpectedConditions.elementToBeClickable(By.xpath(SEARCH_MEDICATION_DOSE_FREQUENCY_UNIT_DURATION_XPATH)));

//        return driver.findElement(By.cssSelector(Assessment_css));
    }

    public WebElement clickSearchMedicationDoseDateDiscontinued() {
        return wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(SEARCH_MEDICATION_DATE_DISCONTINUED_CSS)));

//        return driver.findElement(By.cssSelector(Assessment_css));
    }
    public WebElement clickSearchMedicationSubmitButton() {
        return wait.until(ExpectedConditions.elementToBeClickable(By.xpath(MEDICATION_LIST_SUBMIT_BUTTON_XPATH)));

//        return driver.findElement(By.cssSelector(Assessment_css));
    }


    }
