package locators;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class CommonLocators {
    private WebDriverWait wait;
    private WebDriver driver;
    private String USERNAME_EMAIL_ID = "email";
    private String USERNAME_PASSWORD_ID ="password";
    private String USERNAME_BUTTON_CSS ="button[type='submit']";

    private String Senior_Tanu_CSS = "tbody.MuiTableBody-root>tr:nth-of-type(1)";
    private String Assessment_css = "div[class='MuiBox-root css-1lzo07v-container']>div:nth-child(4)";

    public CommonLocators(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(15));


    }
    public WebElement enterUsername() {

//        return wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(USERNAME_EMAIL_ID)));

        return driver.findElement(By.id(USERNAME_EMAIL_ID));
    }
    public WebElement enterPassword(){return driver.findElement(By.id(USERNAME_PASSWORD_ID));}
    public WebElement clickButton(){return driver.findElement(By.cssSelector(USERNAME_BUTTON_CSS));}
    public WebElement clickSenior() {

        System.out.println("Waiting for senior click");
        return wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector(Senior_Tanu_CSS)));



//        return driver.findElement(By.cssSelector(Senior_Tanu_CSS));
    }

    public WebElement clickAssessment() {
        return wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(Assessment_css)));

//        return driver.findElement(By.cssSelector(Assessment_css));
    }
}



