//package steps;
//import core.WebDriverHook;
//import io.cucumber.java.en.And;
//import io.cucumber.java.en.Given;
//import io.cucumber.java.en.Then;
//import io.cucumber.java.en.When;
//import locators.DashboardLocators;
//
//import locators.LoginLocators;
//
//import static org.junit.Assert.assertEquals;
//
//public class DashboardPageSteps {
//    private DashboardLocators dashboardLocators;
//    private WebDriverHook webDriverHook;
//    public DashboardPageSteps() {
//        webDriverHook = WebDriverHook.getInstance();
//        dashboardLocators = new DashboardLocators(webDriverHook.getDriver());
//    }
//    @Given("user is login page")
//    public void goToWebApp() {
//        dashboardLocators = new DashboardLocators(webDriverHook.getDriver());
//    }
//
//
//    @When("user enters the email address {string}")
//    public void enterEmail(String firstName) {
//        dashboardLocators.enterUsername().sendKeys(firstName);
//    }
//
//
//    @And("user enters the password {string}")
//    public void enterPassword(String firstName) {
//        dashboardLocators.enterPassword().sendKeys(firstName);
//    }
//
//    @And("user clicks on submit button")
//    public void clickSubmit() {
//        loginLocators.clickButton().click();
//    }
//
//    @Then("the website title should be {string}")
//    public void verifyWebsiteTitle(String expectedTitle) {
//        String actualTitle = webDriverHook.getDriver().getTitle();
//        assertEquals("Unexpected website title", expectedTitle, actualTitle);
//        System.out.println("Website title assertion passed!");
//
//    }
//}
//
//}
