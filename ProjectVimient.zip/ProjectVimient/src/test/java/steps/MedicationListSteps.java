package steps;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import locators.MedicationListLocators;
import core.WebDriverHook;
import io.cucumber.java.en.Given;
import locators.LoginLocators;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.Keys;
import java.time.Duration;


import java.time.Duration;

import static core.WebDriverHook.driver;
import static org.junit.Assert.assertEquals;

public class MedicationListSteps {
    private MedicationListLocators medicationListLocators;


    private WebDriverHook webDriverHook;

    // Constructor to initialize WebDriverHook and LoginLocator
    public MedicationListSteps() {
        webDriverHook = WebDriverHook.getInstance();
        medicationListLocators = new MedicationListLocators(webDriverHook.getDriver());
    }

//    @Given("user is on login page")
//    public void goToWebApps() {
//        medicationListLocators = new MedicationListLocators(webDriverHook.getDriver());
//    }
//
//
//    @When("user enters the email address {string}")
//    public void enterEmailMedication(String firstName) {
//
//        medicationListLocators.enterUsername().sendKeys(firstName);
//    }
//
//
//    @And("user enters the password and {string}")
//    public void enterPasswordMedication(String firstName) {
//        medicationListLocators.enterPassword().sendKeys(firstName);
//    }
//
//    @And("user clicks on submit button")
//    public void clickSubmitMedication() {
//        medicationListLocators.clickButton().click();
//    }
//
//    @Then("the website title should be {string}")
//    public void verifyWebsiteTitleMedication(String expectedTitle) throws InterruptedException {
//        try {
//            medicationListLocators.clickSenior().click();
//        } catch (Exception e) {
//            System.out.println("Exception" + e);
//        }
//        String actualTitle = webDriverHook.getDriver().getTitle();
//        assertEquals("Unexpected website title", expectedTitle, actualTitle);
//        System.out.println("Website title assertion passed!");
//        Thread.sleep(5000);
//        webDriverHook.refreshBrowser();
//        Thread.sleep(10000);
//
//
//
//    }
//
//
//    @When("user click on senior")
//    public void userClickOnSeniorMedication() throws InterruptedException {
//
//        medicationListLocators.clickSenior().click();
//        Thread.sleep(10000);
//
//
//    }
//
//
//    // ... Existing code ...
//
//    @And("user click on assessment")
//    public void userClickOnAssessmentMedication() throws InterruptedException {
//        // Wait for overlay to disappear
//        WebDriverWait overlayWait = new WebDriverWait(driver, Duration.ofSeconds(15));
//        overlayWait.until(ExpectedConditions.invisibilityOfElementLocated(By.cssSelector(".MuiBackdrop-root")));
//
//        // Find the assessment element
//        WebElement assessmentElement = medicationListLocators.clickAssessment();
//
//        // Scroll the assessment element into view using JavascriptExecutor
//        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", assessmentElement);
//
//        // Click on the assessment element
//        assessmentElement.click();
//
//        Thread.sleep(15000);
//


//    }
    @And("user click on medication list")
    public void userClickOnMedicationList() throws InterruptedException {

        medicationListLocators.clickMedicationList().click();
    }
    @And("user click on add medication")
    public void userClickOnAddMedication() throws InterruptedException {
        // Find the add medication element
        WebElement addMedicationElement = medicationListLocators.clickAddMedication();

        // Scroll the add medication element into view using JavascriptExecutor
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", addMedicationElement);

        // Click on the add medication element
        addMedicationElement.click();
    }



    @And("user click on search medication type and enter {string}")
    public void userClickOnSearchMedication(String message) throws InterruptedException {
        medicationListLocators.clickSearchMedication().click();

        WebElement medicationList = medicationListLocators.clickSearchMedication();


        // Enter the search string
        medicationList.sendKeys(message);
        Thread.sleep(5000);

        medicationListLocators.clickSearchMedicationOption().click();


        // Wait for the dropdown to appear (you may need to implement this)
        // Then, use the arrow keys to navigate to the 2nd option and press Enter
//        for (int i = 0; i < 2; i++) {
//            medicationList.sendKeys(Keys.ARROW_DOWN);
//
//
//        }
//        System.out.println("de3");
//
//        medicationList.sendKeys(Keys.ENTER);


    }

    @And("user click on search medication dose form and enter name")
    public void userClickOnMedicationListDoseForm()  {

        medicationListLocators.clickSearchMedicationDoseForm().click();
        medicationListLocators.clickSearchMedicationDoseFormName().click();
    }
    @And("user click on search medication duration")
    public void userClickOnMedicationListDuration() {

        medicationListLocators.clickSearchMedicationDoseDuration().click();
    }
    @And("user click on search medication date prescribed")
    public void userClickOnMedicationListDatePrescribed() throws InterruptedException {
        medicationListLocators.clickSearchMedicationDatePrescribed().click();
        String year = "2023";
        String month = "June";
        while (true) {
            String monthYear = driver.findElement(By.cssSelector("div[class='MuiPickersFadeTransitionGroup-root css-1bx5ylf']>div:nth-child(1)")).getText();
            String[] arr = monthYear.split(" ");

            if (arr.length >= 2) {
                String mon = arr[0];
                String yr = arr[1];

                if (mon.equalsIgnoreCase(month) && yr.equals(year)) {
                    break;
                } else {
                    driver.findElement(By.cssSelector("button[aria-label='Previous month']")).click();
                }
            }
//            else {
//                // Handle the case when monthYear doesn't contain a space character.
//                // You can add logging or error handling here.
//                // For example, you can throw an exception or print an error message.
//                System.err.println("Month and year not found in: " + monthYear);
//                break; // Exit the loop or handle it according to your needs.
//            }
        }

        System.out.println("work start");
        Thread.sleep(3000);
        driver.findElement(By.xpath("//button[text()='16']")).click();
        System.out.println("work end");
    }



    @And("user click on search medication textarea and send message {string}")
    public void userClickOnMedicationListTextArea(String message) {

        medicationListLocators.clickSearchMedicationTextArea().click();
        medicationListLocators.clickSearchMedicationTextArea().sendKeys(message);
    }
    @And("user click on search medication dose frequnecy and select frequncy time")
    public void userClickOnMedicationListFrequnecyTime() {

        medicationListLocators.clickSearchMedicationDoseFrquencyTIME().click();
        medicationListLocators.clickSearchMedicationDoseFrquencyTIMENo().click();
    }
    @And("user click on search medication dose frequnecy and select frequncy unit")
    public void userClickOnMedicationListFrequencyUnit() {

        medicationListLocators.clickSearchMedicationDoseFrquencyUNIT().click();
        medicationListLocators.clickSearchMedicationDoseFrquencyUNITDuration().click();
    }
    @And("user click on search medication date continued and enter date {string}")
    public void userClickOnMedicationListDateDiscontinued(String date) {
         medicationListLocators.clickSearchMedicationDoseDateDiscontinued().click();
        medicationListLocators.clickSearchMedicationDoseDateDiscontinued().sendKeys(date);
    }

    @And("user click on search medication submit button")
    public void userClickOnMedicationListSubmitButton() {
        medicationListLocators.clickSearchMedicationSubmitButton().click();
    }


}