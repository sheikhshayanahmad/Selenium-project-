package steps;

import core.WebDriverHook;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import locators.CommonLocators;
import locators.LoginLocators;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

import static core.WebDriverHook.driver;
import static org.junit.Assert.assertEquals;

public class CommonSteps {
    private CommonLocators commonLocators;


    private WebDriverHook webDriverHook;

    // Constructor to initialize WebDriverHook and LoginLocator
    public CommonSteps() {
        webDriverHook = WebDriverHook.getInstance();
        commonLocators = new CommonLocators(webDriverHook.getDriver());
    }
    @Given("user is login page")
    public void goToWebApp() {
        commonLocators = new CommonLocators(webDriverHook.getDriver());
    }


    @When("user enters the email address {string}")
    public void enterEmail(String firstName) {

        commonLocators.enterUsername().sendKeys(firstName);
    }


    @And("user enters the password {string}")
    public void enterPassword(String firstName) {
        commonLocators.enterPassword().sendKeys(firstName);
    }

    @And("user clicks on submit button")
    public void clickSubmit() {
        commonLocators.clickButton().click();
    }

    @Then("the website title should be {string}")
    public void verifyWebsiteTitle(String expectedTitle) throws InterruptedException {
        try {
            commonLocators.clickSenior().click();
        } catch (Exception e) {
            System.out.println("Exception" + e);
        }
        String actualTitle = webDriverHook.getDriver().getTitle();
        assertEquals("Unexpected website title", expectedTitle, actualTitle);
        System.out.println("Website title assertion passed!");
        Thread.sleep(5000);
        webDriverHook.refreshBrowser();
        Thread.sleep(5000);

    }


    @When("user click on senior")
    public void userClickOnSenior() throws InterruptedException {

        commonLocators.clickSenior().click();
        Thread.sleep(10000);
    }
    @When("user click on assessment")
    public void userClickOnAssessment() throws InterruptedException {
        // Wait for overlay to disappear
        WebDriverWait overlayWait = new WebDriverWait(driver, Duration.ofSeconds(15));
        overlayWait.until(ExpectedConditions.invisibilityOfElementLocated(By.cssSelector(".MuiBackdrop-root")));

        // Find the assessment element
        WebElement assessmentElement = commonLocators.clickAssessment();

        // Scroll the assessment element into view using JavascriptExecutor
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", assessmentElement);

        // Click on the assessment element
        assessmentElement.click();

        Thread.sleep(5000);
    }
}
