package steps;
import io.cucumber.java.bs.A;
import io.cucumber.java.en_scouse.An;
import locators.LoginLocators;

import io.cucumber.java.en.When;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import core.WebDriverHook;
import org.openqa.selenium.JavascriptExecutor;
import java.time.Duration;
import static core.WebDriverHook.driver;
import static org.junit.Assert.assertEquals;
import org.openqa.selenium.Alert;
import org.openqa.selenium.TimeoutException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


public class LoginPageSteps {

    private LoginLocators loginLocators;


    private WebDriverHook webDriverHook;

    // Constructor to initialize WebDriverHook and LoginLocator
    public LoginPageSteps() {
        webDriverHook = WebDriverHook.getInstance();
        loginLocators = new LoginLocators(webDriverHook.getDriver());
    }


//    @Given("user is login page")
//    public void goToWebApp() {
//        loginLocators = new LoginLocators(webDriverHook.getDriver());
//    }
//
//
//    @When("user enters the email address {string}")
//    public void enterEmail(String firstName) {
//
//        loginLocators.enterUsername().sendKeys(firstName);
//    }
//
//
//    @And("user enters the password {string}")
//    public void enterPassword(String firstName) {
//        loginLocators.enterPassword().sendKeys(firstName);
//    }
//
//    @And("user clicks on submit button")
//    public void clickSubmit() {
//        loginLocators.clickButton().click();
//    }
//
//    @Then("the website title should be {string}")
//    public void verifyWebsiteTitle(String expectedTitle) throws InterruptedException {
//        try {
//            loginLocators.clickSenior().click();
//        } catch (Exception e) {
//            System.out.println("Exception" + e);
//        }
//        String actualTitle = webDriverHook.getDriver().getTitle();
//        assertEquals("Unexpected website title", expectedTitle, actualTitle);
//        System.out.println("Website title assertion passed!");
//        Thread.sleep(5000);
//        webDriverHook.refreshBrowser();
//        Thread.sleep(5000);
//
//
//
//    }
//
//
//    @When("user click on senior")
//    public void userClickOnSenior() throws InterruptedException {
//
//            loginLocators.clickSenior().click();
//        Thread.sleep(10000);
//
//
//    }
//
//
//        // ... Existing code ...
//
//        @When("user click on assessment")
//        public void userClickOnAssessment() throws InterruptedException {
//            // Wait for overlay to disappear
//            WebDriverWait overlayWait = new WebDriverWait(driver, Duration.ofSeconds(15));
//            overlayWait.until(ExpectedConditions.invisibilityOfElementLocated(By.cssSelector(".MuiBackdrop-root")));
//
//            // Find the assessment element
//            WebElement assessmentElement = loginLocators.clickAssessment();
//
//            // Scroll the assessment element into view using JavascriptExecutor
//            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", assessmentElement);
//
//            // Click on the assessment element
//            assessmentElement.click();
//
//            Thread.sleep(15000);
//        }

        // ... Other existing methods ...






    @When("user click on well-being survey")
    public void userClickOnWellBeingSurvey() throws InterruptedException {


            loginLocators.clickWellBeingSurvey().click();
      Thread.sleep(15000);


    }



    @And("user click on well-being survey bored radio button")
    public void userClickOnWellBeingSurveyBoredRadio() throws InterruptedException {


            loginLocators.clickWellBeingBored().click();


    }


    @And("user enter the well-being survey bored message {string}")
    public void userClickOnWellBeingSurveyBoredRadioTextArea(String message) throws InterruptedException {

        WebElement wellBeingBoredTextArea = loginLocators.clickWellBeingBoredTextArea();

        // Clear the existing text in the textarea
        wellBeingBoredTextArea.clear();

        // Send the new message to the textarea
        wellBeingBoredTextArea.sendKeys(message);
    }


    @And("user click on well-being survey bored level")
    public void userClickOnWellBeingSurveyBoredLevel() {

            loginLocators.clickWellBeingBoredLevel().click();
        }

//        functions for Well being happy
@And("user click on well-being survey happy radio button")
public void userClickOnWellBeingSurveyHappy() {
    loginLocators.clickWellBeingHappy().click();

}
    @And("user click on well-being survey happy text area {string}")
    public void userClickOnWellBeingSurveyHappyTextArea(String message) {
        loginLocators.clickWellBeingHappyTextArea().sendKeys(message);

    }


    @And("user click on well-being survey no purpose radio button")
        public void userClickOnWellBeingSurveyNoPurpose() {
            loginLocators.clickWellBeingNoPurpose().click();

        }

@And("user click on well-being survey no purpose text area {string}")
public void userClickOnWellBeingSurveyNoPurposeTextArea(String message) {
    loginLocators.clickWellBeingNoPurposeTextArea().sendKeys(message);

}
    @And("user click on well-being survey no purpose level")
    public void userClickOnWellBeingPurposeLevel() {
        loginLocators.clickWellBeingNoPurposeLevel().click();
//        loginLocators.handleAlertAfterReset();
    }
    @And("user click on well-being survey social radio button")
    public void userClickOnWellBeingSocial() {
        loginLocators.clickWellBeingSocial().click();
//        loginLocators.handleAlertAfterReset();
    }
    @And("user click on well-being survey stressed radio button")
    public void userClickOnWellBeingStressed() {
        loginLocators.clickWellBeingStressed().click();
//        loginLocators.handleAlertAfterReset();
    }
    @And("user click on well-being survey stressed level button")
    public void userClickOnWellBeingStressedLevel() {
        loginLocators.clickWellBeingStressedLevel().click();
//        loginLocators.handleAlertAfterReset();
    }
    @And("user click on well-being survey pain free radio button")
    public void userClickOnWellBeingPainFree() {
        loginLocators.clickWellBeingPainFree().click();
//        loginLocators.handleAlertAfterReset();
    }

    @And("user click on well-being survey rested radio button")
    public void userClickOnWellBeingRested() {
        loginLocators.clickWellBeingRESTED().click();
//        loginLocators.handleAlertAfterReset();
    }
    @And("user click on well-being survey submit button")
    public void userClickOnWellBeingSubmitButton() {
        loginLocators.clickWellBeingSubmitButton().click();
//        loginLocators.handleAlertAfterReset();
    }



    @And("user click on well-being survey reset button")
    public void userClickOnWellBeingSurveyResetButton() throws InterruptedException {
        loginLocators.clickWellBeingResetButton().click();
//        loginLocators.handleAlertAfterReset();
        Thread.sleep(3000);
    }


    @Then("user can click on well-being survey reset button ok button")
    public void userClickOnWellBeingSurveyResetButtonOk() throws InterruptedException {
        loginLocators.clickWellBeingResetButtonOK().click();
        Thread.sleep(5000);
//        loginLocators.handleAlertAfterReset();
    }
 @And("user can click on well-being survey reset button ok then cross button")
         public void userClickOnWellBeingSurveyResetButtonOkCrossButton() throws InterruptedException {
         loginLocators.clickWellBeingResetButtonOKCross().click();
         Thread.sleep(5000);
//        loginLocators.handleAlertAfterReset();
         }


    }





